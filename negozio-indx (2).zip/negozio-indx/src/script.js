// Paste into JS panel
document.addEventListener('DOMContentLoaded', () => {
  const accordions = Array.from(document.querySelectorAll('.accordion'));

  // init panels
  accordions.forEach(btn => {
    const panel = document.getElementById(btn.getAttribute('aria-controls')) || btn.nextElementSibling;
    if (!panel) return;
    panel.style.maxHeight = null;
    panel.setAttribute('aria-hidden', 'true');
    btn.setAttribute('aria-expanded', 'false');

    // toggle function
    function toggle() {
      const isOpen = btn.getAttribute('aria-expanded') === 'true';
      if (isOpen) {
        btn.setAttribute('aria-expanded', 'false');
        panel.setAttribute('aria-hidden', 'true');
        panel.style.maxHeight = null;
      } else {
        // close others
        accordions.forEach(otherBtn => {
          const otherPanel = document.getElementById(otherBtn.getAttribute('aria-controls')) || otherBtn.nextElementSibling;
          if (otherBtn !== btn && otherPanel) {
            otherBtn.setAttribute('aria-expanded', 'false');
            otherPanel.setAttribute('aria-hidden', 'true');
            otherPanel.style.maxHeight = null;
          }
        });
        btn.setAttribute('aria-expanded', 'true');
        panel.setAttribute('aria-hidden', 'false');
        panel.style.maxHeight = panel.scrollHeight + 'px';
      }
    }

    btn.addEventListener('click', toggle);
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggle();
      }
    });

    // keep height correct on resize if open
    window.addEventListener('resize', () => {
      if (btn.getAttribute('aria-expanded') === 'true') {
        panel.style.maxHeight = panel.scrollHeight + 'px';
      }
    });
  });
});
